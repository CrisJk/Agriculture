package main;
import javax.xml.transform.Result;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;


/**
 * Created by ecnu_kuangjun on 7/12/17.
 * 数据导入类的父类,导入每一张表的类都继承该类
 */
public class DataImport {
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    /**
     * 获取数据库连接
     * @param url:数据库url
     * @return :返回数据库连接
     */
    protected Connection getConnection(String url){
        try {
            this.connection = JDBCTools.getConnection(url);
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return this.connection;
    }

    /**
     * 获取PreparedStatement
     * @param sql SQL语句
     * @return PreparedStatement
     */
    protected PreparedStatement getPreparedStatement(String sql,Connection newConnection){
        try {
            this.preparedStatement=newConnection.prepareStatement(sql);
        } catch (SQLException e) {
            //e.printStackTrace();
        }
        return this.preparedStatement;
    }


}
